package com.appweb.devfm.demo.enums;

public enum Role {
    user,
    manager,
    admin
}