package com.appweb.devfm.demo.enums;

public enum ResponseStatus
{
    success,
    error
}