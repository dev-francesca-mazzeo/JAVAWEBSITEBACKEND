package com.appweb.devfm.demo.utils;

public class Helper {
    public static boolean notNull(Object obj){
        return obj != null;
    }
}