package com.appweb.devfm.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevfmApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevfmApplication.class, args);
		System.out.println("Hello System!");
	}

}
